# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src_train']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'src-train',
    'version': '0.1.0',
    'description': 'Preprocessing function to train',
    'long_description': '## modulo_II\n\nPackage to build resources for Titanic model preprocces and training\n\nInitially appeared on\n[gist](https://github.com/RoSaav/modulo_III).\n\n## Getting Started\n\nThese instructions will give you a copy of the project up and running on\nyour local machine for development and testing purposes. See deployment\nfor notes on deploying the project on a live system.\n\n### Prerequisites\n\nRequirements for the software and other tools to build, test and push \n- Python 3.9.x\n\n### Installing - Microsoft Windows\n\nA step by step series of examples that tell you how to get a development\nenvironment running\n\nRun the next lines in a powershell\n\n-pip install virtualenv\n\n-virtualenv todos_env\n\n-todos_env\\Scripts\\activate\n\n-pip install -r requirements.txt\n \n## Running the tests\n\nIf you want to run test pre installation you can run all the test in project or unit/integration with the next lines\n\n-tox -v\n\n\n### Sample Tests\n\ntest\\integration\\test_integration.py .                                                                                         [ 25%] \ntest\\unit\\test_extract_cabin.py .                                                                                              [ 50%] \ntest\\unit\\test_extract_title.py .                                                                                              [ 75%] \ntest\\unit\\test_type_converter.py .                                                                                             [100%] \n\n=================================================== 4 passed, 1 warning in 4.91s ==================================================== \n-______________________________________________________ summary -______________________________________________________\n\n-  py39: commands succeeded\n\n-  congratulations :)\n\n\n## Authors\n\nHomework for MODULO_II\n\nTECNOLOGICO DE MONTERREY\n\nMiguel Rodrigo Saavedra Perez\n\nhttps://github.com/RoSaav/modulo_II\n\n\n## License\n\nThis project is licensed under the [MIT](LICENSE.md)\nCreative Commons License - see the [LICENSE.md](LICENSE.md) file for\ndetails\n',
    'author': 'RoSaavedra',
    'author_email': '55178179+RoSaavedra@users.noreply.github.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
